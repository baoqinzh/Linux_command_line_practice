# commandlinebasics
Exercise Files for the Learning Linux Command Line course at [LinkedIn Learning](http://bit.ly/lil-llcl) and [Lynda.com](http://bit.ly/lynda-llcl).
